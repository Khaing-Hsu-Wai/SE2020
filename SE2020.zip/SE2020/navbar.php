<!-- NAVBAR -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="brand">
				<p><b>Product Item Module</b></p>
			</div>

			<div class="container-fluid">
				<div class="navbar-btn">
					<button type="button" class="btn-toggle-fullwidth"><i class="lnr lnr-arrow-left-circle"></i></button>
				</div>

				<div id="navbar-menu">
					<ul class="nav navbar-nav navbar-right">
						<h1><b>ZEROONE</b></h1>
					</ul>
				</div>
			</div>
		</nav>
		<!-- END NAVBAR -->