		<footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2020 <a href="https://www.themeineed.com" target="_blank"> SE2020,</a>Developed by ZEROONE</p>
			</div>
		</footer>
	</div>
	<!-- END WRAPPER -->
	
</body>

</html>