<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li>
							<a href="item.php" class=""><i class="lnr lnr-list"></i> <span>Item</span>
							</a>
						</li>

						<li>
							<a href="itemlist.php" class=""><i class="lnr lnr-list"></i> <span>Item List</span>
							</a>
						</li>
						
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->